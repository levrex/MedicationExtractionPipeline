edgeXMLSkel=\
u"""
<edge>
<startNode> {0} </startNode>
<endNode> {1} </endNode>
{2}
</edge>
"""

nodeXMLSkel=\
u"""
<node>
{0}
</node>
"""

