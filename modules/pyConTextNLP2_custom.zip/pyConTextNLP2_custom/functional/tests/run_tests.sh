nose2 -t ../../../pyConTextNLP
