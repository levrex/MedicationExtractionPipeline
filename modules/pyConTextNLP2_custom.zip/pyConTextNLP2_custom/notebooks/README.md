# Read in order

These notebooks walk through pyConTextNLP concepts in order of complexity. Recommended reading order is:

1. [BasicSentenceMarkup](./BasicSentenceMarkup.ipynb)
2. [BasicSentenceMarkupPart2](./BasicSentenceMarkupPart2.ipynb)
3. [MultiSentenceDocuments](./MultiSentenceDocuments.ipynb)
